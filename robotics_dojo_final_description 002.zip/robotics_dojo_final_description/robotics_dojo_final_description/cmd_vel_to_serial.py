#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial

class CmdVelToSerial(Node):
    def __init__(self):
        super().__init__('cmd_vel_to_serial')
        
        # Serial setup
        self.serial_port = serial.Serial(
            port='/dev/ttyUSB0',  # Adjust this to your port
            baudrate=57600,
            timeout=1.0
        )
        
        # Subscribe to cmd_vel
        self.subscription = self.create_subscription(
            Twist,
            'cmd_vel',
            self.cmd_vel_callback,
            10)
            
        self.get_logger().info('Serial Motor Controller Node Started')

    def cmd_vel_callback(self, msg):
        # Convert Twist to motor speeds
        # Assuming differential drive setup
        left_speed = int((msg.linear.x - msg.angular.z) * 100)  # Scale as needed
        right_speed = int((msg.linear.x + msg.angular.z) * 100)  # Scale as needed
        
        # Format motor command: m left:left:right:right
        cmd = f"m {left_speed}:{left_speed}:{right_speed}:{right_speed}\r"
        self.get_logger().info(f'Sending command: {cmd.strip()}')
        self.serial_port.write(cmd.encode())
        
        # Try to read response
        try:
            response = self.serial_port.readline()
            self.get_logger().info(f'Received response: {response}')
        except Exception as e:
            self.get_logger().error(f'Error reading response: {e}')
        
    def __del__(self):
        if hasattr(self, 'serial_port'):
            self.serial_port.close()

def main():
    rclpy.init()
    node = CmdVelToSerial()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()