#!/usr/bin/env python3
import serial
import sys

print("Checking serial port...")
try:
    ser = serial.Serial('/dev/ttyUSB0', 57600, timeout=1)
    print("Serial port opened successfully")
    print(f"Port: {ser.name}")
    print(f"Baudrate: {ser.baudrate}")
    print(f"Is open: {ser.is_open}")
    ser.close()
    print("Port closed successfully")
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)