#!/usr/bin/env python3
import serial
import time
import sys

def test_connection(baudrate):
    print(f"\nTrying baudrate: {baudrate}")
    try:
        # Configure the serial connection
        ser = serial.Serial(
            port='/dev/ttyUSB0',
            baudrate=baudrate,
            timeout=1
        )
        print(f"Opened port at {baudrate} baud")
        return ser
    except serial.SerialException as e:
        print(f"Error opening port: {e}")
        return None

# Try different common baudrates
baudrates = [9600, 57600, 115200]

ser = None
for rate in baudrates:
    ser = test_connection(rate)
    if ser is not None:
        break

if ser is None:
    print("Could not open serial port with any baudrate")
    sys.exit(1)

try:
    print("Serial port opened successfully")
    
    # Send a ping command first
    print("Sending ping command 'p'...")
    ser.write(b'p\r')
    response = ser.readline()
    print(f"Ping response: {response}")
    
    # Try sending a motor command
    print("\nSending motor stop command 'm 0:0:0:0'...")
    ser.write(b'm 0:0:0:0\r')
    response = ser.readline()
    print(f"Motor command response: {response}")
    
    # Wait a bit
    time.sleep(1)
    
    # Try moving forward slightly
    print("\nSending forward command 'm 50:50:50:50'...")
    ser.write(b'm 50:50:50:50\r')
    response = ser.readline()
    print(f"Forward command response: {response}")
    
    # Wait a bit
    time.sleep(1)
    
    # Stop motors
    print("\nStopping motors...")
    ser.write(b'm 0:0:0:0\r')
    response = ser.readline()
    print(f"Stop command response: {response}")

except Exception as e:
    print(f"An error occurred: {e}")
finally:
    ser.close()
    print("\nSerial port closed")